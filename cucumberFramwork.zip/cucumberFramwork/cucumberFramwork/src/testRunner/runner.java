package testRunner;

import org.junit.AfterClass;
import org.junit.runner.RunWith;


import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import step.extentReport;

@RunWith(Cucumber.class)
@CucumberOptions(features= {"Feature"},
                 glue= {"step"},
                 monochrome= true,
                 tags= {"@datatable"})

public class runner {
	
	
}
