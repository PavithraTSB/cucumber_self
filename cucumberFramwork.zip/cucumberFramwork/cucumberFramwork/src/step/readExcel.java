package step;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class readExcel {
	public  String readExcel(int dataRow,int cellnumb) throws IOException
	{
		String value=null;
		try {
			
			File file=new File("./Excel/dataTablexl.xls");
			FileInputStream fi=new FileInputStream(file);
			HSSFWorkbook wb=new HSSFWorkbook(fi);
			HSSFSheet sh=wb.getSheet("DatatableSheet");
			HSSFRow row=sh.getRow(dataRow);
			HSSFCell cell=row.getCell(cellnumb);
			value=cell.getStringCellValue();
			
			System.out.println("Print data ="+value);
		} catch (Exception e) {
			System.out.println("Read data is not successfull");
			e.printStackTrace();
		}
		return value;
		
	}
}
