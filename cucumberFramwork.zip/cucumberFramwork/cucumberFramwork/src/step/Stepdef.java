package step;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class Stepdef {

	WebDriver driver;  
	LinkedHashMap<String,String>hm=new LinkedHashMap<>();
	LinkedHashMap<String,String>hmSalary=new LinkedHashMap<>();
	File file;
	HSSFWorkbook wb;
	HSSFSheet sh;
	HSSFRow row;
	HSSFCell cell;
	HSSFCellStyle style;
	HSSFCellStyle style1;
	HSSFFont font;
	HSSFFont font1;
	readExcel rc=new readExcel();
	
	

	@Given("^Launch the url \"([^\"]*)\"$")
	public void launch_the(String url) throws Throwable {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//a[text()='Login']")).click();
		System.out.println("Login button clicked");

	}

	@When("^I enter the valid (.*) and (.*)$")
	public void i_enter_the_valid_and(String Username, String Password) throws Throwable {
		driver.findElement(By.id("inputEmail")).sendKeys(Username);
		driver.findElement(By.id("inputPassword")).sendKeys(Password);
		driver.findElement(By.id("login")).click();


	}

	@Then("^user should be able login successfully$")
	public void user_should_be_able_login_successfully() throws Throwable {
		System.out.println("Login Successfull");

	}
	@Given("^Launch the webtableURL \"([^\"]*)\"$")
	public void Login(String url) throws IOException {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();

		 
	}

	@When("^I fetch the datas$")
	public LinkedHashMap<String,String> fetchData()  {

		 hm=new LinkedHashMap<String,String>();
		
		String key;
		String value;
		
		int count=1;

		try {
			WebElement entryDropdown=driver.findElement(By.xpath("//select[@name='example_length']"));
			Select se=new Select(entryDropdown);
			se.selectByVisibleText("100");
			List<WebElement>tableRow=driver.findElements(By.xpath("//table[@id='example']//tbody//tr"));
			for(int i=0;i<tableRow.size();i++) {
				value=tableRow.get(i).getText();
				key="DataRow_"+count;
				System.out.println("Key :"+key+"|"+"Value :"+value);
				hm.put(key,value);
				count++;

			}
			
			  List<WebElement>clickSort=driver.findElements(By.xpath("//td[@class='sorting_1']")); 
			  for(int j=0;j<clickSort.size();j++) {
			
			  clickSort.get(j).click();
			  List<WebElement>salary=driver.findElements(By.xpath("//span[@class='dtr-data']"));
			  value=salary.get(j).getText();
			  key="Salary_"+count; 
			  hmSalary.put(key,value);
			  System.out.println("Key :"+key+"|"+"Value :"+value); 
			  count++;
			  
			  }
			 
			 		 			
		} catch (Exception e) {
			System.out.println("Fetch data is not success"+e.getMessage());
			e.printStackTrace();
		}
		return hm;
	}
	@When("^Add hashmap datas to Excel sheet$")
	public void writeExcel() throws IOException {
		System.out.println("Hashmap values :"+hm);
		System.out.println("HashMap Salary Values :"+hmSalary);
		int rownum=1;
		

		try {
			file=new File("./Excel/dataTablexl.xls");
			wb=new HSSFWorkbook();
			sh=wb.createSheet("DatatableSheet");
			// create font
			font= wb.createFont();
			font.setFontHeightInPoints((short)14);
			font.setFontName("Arial");
			font.setColor(IndexedColors.RED.getIndex());
			font.setItalic(false);

			style=wb.createCellStyle();
			style.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style.setAlignment(CellStyle.ALIGN_CENTER);
			style.setFont(font);

			font1= wb.createFont();
			font1.setFontHeightInPoints((short)10);
			font1.setFontName("Arial");
			font1.setItalic(false);

			style1=wb.createCellStyle();
			style1.setBorderBottom(HSSFCellStyle.BORDER_THIN);
			style1.setBorderLeft(HSSFCellStyle.BORDER_THIN);
			style1.setBorderRight(HSSFCellStyle.BORDER_THIN);
			style1.setBorderTop(HSSFCellStyle.BORDER_THIN);
			style1.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			style1.setFont(font1);

			Set<String>keyset=hm.keySet();
			row=sh.createRow(0);
			cell=row.createCell(0);
			cell.setCellValue("KEY");
			cell.setCellStyle(style);
			cell=row.createCell(1);
			cell.setCellValue("Personal Details");
			cell.setCellStyle(style);
			cell=row.createCell(2);
			cell.setCellValue("SALARY");
			cell.setCellStyle(style);



			for (String key : keyset)
			{ 
				row=sh.createRow(rownum++); 
				cell=row.createCell(0);
				cell.setCellValue(key);
				cell.setCellStyle(style1);

				List<String> keys= new ArrayList<String>();

				keys.add(hm.get(key));

				for(int i=0;i<keys.size();i++) 
				{ 
					cell=row.createCell(1); 
					cell.setCellValue(keys.get(i));
					cell.setCellStyle(style1);

				}
			}
			rownum=1;
			Set <String>salaryKey=hmSalary.keySet();
			for (String salary : salaryKey) {
				if(sh.getRow(rownum)==null)
				{
					
				row=sh.createRow(rownum++);
				}
				else 
				{
					row.setRowNum(rownum++);
				}
				List<String> salaryKeys=new ArrayList<String>();
				salaryKeys.add(hmSalary.get(salary));
				
				for(int j=0;j<salaryKeys.size();j++) 
				{ 
					cell=row.createCell(2); 
					cell.setCellValue(salaryKeys.get(j));
					cell.setCellStyle(style1);

				}
				
			}

			FileOutputStream fs=new FileOutputStream(file);
			wb.write(fs);
			fs.close();
		} catch (Exception e) {
			System.out.println("Data Write is not successfull");
			e.printStackTrace();
		}

	}

	
	@And("^Search the data from Excel sheet (.*) and (.*)$")
	public void searchData(int dataRow,int cellnumb) {
		try {
			String output=rc.readExcel(dataRow, cellnumb);
			System.out.println("OUTPUT ="+output);
			WebElement search=driver.findElement(By.xpath("//input[@type='search']"));
			search.sendKeys(output);
		} catch (IOException e) {
			System.out.println("Search is not Successfull"+e.getMessage());
			e.printStackTrace();
		}
	}
	@Then("^user should be able to fetch data successfully$")
	public void Logout() {

		driver.quit();
	}




}