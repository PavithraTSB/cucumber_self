package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class page {
	@FindBy(how=How.XPATH,using="//a[text()='Login']")WebElement login;
	@FindBy(how=How.ID,using="inputEmail")WebElement uname;
	@FindBy(how=How.ID,using="inputPassword")WebElement pwd;
	@FindBy(how=How.ID,using="login")WebElement submitLogin;
	WebDriver driver;
	
	
	public page() {
		PageFactory.initElements(driver, this);
	
	}
	public void clickLogin(){
		login.click();
	}
	public void clickSubmitLogin() {
		submitLogin.click();
	}
	
}
